#!/bin/bash
# Installs Pinthia in Safari. Double-click this file.
# It turns the "extension" folder next to it into a small Mac app + Safari extension and opens it.
cd "$(dirname "$0")" || exit 1

pause() { echo; read -n 1 -s -r -p "Press any key to close."; }

if ! xcrun --find safari-web-extension-converter >/dev/null 2>&1; then
  echo "Safari extensions need Xcode (free from the App Store)."
  echo "Install it, open it once so it finishes setting up, then double-click this file again."
  pause; exit 1
fi

HERE="$(pwd)"
WORK="$HOME/Library/Application Support/Pinthia-Safari"
rm -rf "$WORK"; mkdir -p "$WORK"

echo "Building Pinthia for Safari (about a minute)..."
xcrun safari-web-extension-converter "$HERE/extension" --project-location "$WORK" --app-name Pinthia \
  --bundle-identifier app.pinthia.Pinthia --macos-only --no-open --no-prompt --force >/dev/null || { echo "Could not convert the extension."; pause; exit 1; }
xcodebuild -project "$WORK/Pinthia/Pinthia.xcodeproj" -scheme Pinthia -configuration Release \
  -derivedDataPath "$WORK/build" CODE_SIGNING_ALLOWED=NO CODE_SIGN_IDENTITY="" build >"$WORK/build.log" 2>&1 \
  || { echo "The build failed. Details: $WORK/build.log"; pause; exit 1; }

APP="$WORK/build/Build/Products/Release/Pinthia.app"
# Safari only loads extensions that are sandboxed, so sign them with that permission
ENT="$WORK/sandbox.entitlements"
cat > "$ENT" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>com.apple.security.app-sandbox</key><true/>
<key>com.apple.security.network.client</key><true/>
</dict></plist>
PLIST
for X in "$APP"/Contents/PlugIns/*.appex; do codesign --force -s - --entitlements "$ENT" "$X" >/dev/null 2>&1; done
codesign --force -s - --entitlements "$ENT" "$APP" >/dev/null 2>&1
mkdir -p "$HOME/Applications"
rm -rf "$HOME/Applications/Pinthia.app"
cp -R "$APP" "$HOME/Applications/Pinthia.app"
xattr -cr "$HOME/Applications/Pinthia.app" 2>/dev/null

pluginkit -a "$HOME/Applications/Pinthia.app/Contents/PlugIns/Pinthia Extension.appex" >/dev/null 2>&1
[ -z "$PINTHIA_NO_OPEN" ] && open "$HOME/Applications/Pinthia.app"
echo
echo "Done. Last step in Safari:"
echo "  Safari > Settings > Extensions > tick Pinthia (allow it on pinterest.com)."
echo "  If Pinthia is not listed: Safari > Develop > Allow Unsigned Extensions"
echo "  (turn on the Develop menu in Safari > Settings > Advanced)."
pause
