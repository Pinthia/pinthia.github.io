// Clicking the toolbar button opens Pinthia in a tab. If the tab you were on is a Pinterest
// board, section, profile or pin.it link, Pinthia loads that link straight away.
const api = globalThis.browser ?? globalThis.chrome;
const PINTEREST = /^https:\/\/([a-z0-9-]+\.)?(pinterest\.[a-z.]+|pin\.it)\//i;

api.action.onClicked.addListener(async (tab) => {
  const link = tab && tab.url && PINTEREST.test(tab.url) ? '?url=' + encodeURIComponent(tab.url) : '';
  await api.tabs.create({ url: api.runtime.getURL('app.html') + link });
});
