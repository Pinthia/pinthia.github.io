// Runs on the Pinthia website only. Marks the page so the site knows the extension is installed and enabled.
document.documentElement.setAttribute('data-pinthia-extension', '1');
window.dispatchEvent(new Event('pinthia-extension'));
